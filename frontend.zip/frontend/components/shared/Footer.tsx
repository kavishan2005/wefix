import { Phone, Mail, MapPin } from 'lucide-react'
import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">WF</span>
              </div>
              <span className="text-xl font-bold">WeFix Lanka</span>
            </div>
            <p className="text-gray-400 mb-4">
              Sri Lanka&apos;s fastest-growing service marketplace connecting customers with trusted professionals.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-400 hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/search" className="text-gray-400 hover:text-white">
                  Find Services
                </Link>
              </li>
              <li>
                <Link href="/providers" className="text-gray-400 hover:text-white">
                  Become a Provider
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-400 hover:text-white">
                  About Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Top Services</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/search?category=plumber" className="text-gray-400 hover:text-white">
                  Plumbers
                </Link>
              </li>
              <li>
                <Link href="/search?category=electrician" className="text-gray-400 hover:text-white">
                  Electricians
                </Link>
              </li>
              <li>
                <Link href="/search?category=driver" className="text-gray-400 hover:text-white">
                  Drivers
                </Link>
              </li>
              <li>
                <Link href="/search?category=tutor" className="text-gray-400 hover:text-white">
                  Tutors
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <Phone className="h-5 w-5 text-orange-400 mt-0.5" />
                <span className="text-gray-400">+94 77 123 4567</span>
              </li>
              <li className="flex items-start space-x-3">
                <Mail className="h-5 w-5 text-orange-400 mt-0.5" />
                <span className="text-gray-400">help@wefix.lk</span>
              </li>
              <li className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-orange-400 mt-0.5" />
                <span className="text-gray-400">Colombo, Sri Lanka</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} WeFix Lanka. All rights reserved.</p>
          <p className="mt-2 text-sm">
            <Link href="/privacy" className="hover:text-white">Privacy Policy</Link> • 
            <Link href="/terms" className="hover:text-white ml-2">Terms of Service</Link>
          </p>
        </div>
      </div>
    </footer>
  )
}
