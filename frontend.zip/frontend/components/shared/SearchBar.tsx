export default function SearchBar() {
  return (
    <div className="bg-white p-4 rounded-xl shadow">
      <p>Search Bar Component</p>
    </div>
  )
}
