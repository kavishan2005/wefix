export default function ServiceCategories() {
  return (
    <div className="bg-white p-4 rounded-xl shadow">
      <p>Service Categories Component</p>
    </div>
  )
}
