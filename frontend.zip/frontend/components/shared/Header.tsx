'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Menu, Wrench } from 'lucide-react'

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
              <Wrench className="w-6 h-6 text-white" />
            </div>
            <div>
              <span className="text-2xl font-bold text-gray-900">WeFix</span>
              <span className="text-xs text-orange-500 font-medium block -mt-1">SRI LANKA</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-600 hover:text-orange-500 font-medium">
              Home
            </Link>
            <Link href="/search" className="text-gray-600 hover:text-orange-500 font-medium">
              Find Services
            </Link>
            <Link href="/providers" className="text-gray-600 hover:text-orange-500 font-medium">
              For Providers
            </Link>
            <Link href="/how-it-works" className="text-gray-600 hover:text-orange-500 font-medium">
              How It Works
            </Link>
          </nav>

          {/* Auth Buttons - Desktop */}
          <div className="hidden md:flex items-center space-x-4">
            <Link href="/login">
              <button className="px-4 py-2 text-gray-600 hover:text-orange-500 font-medium">
                Login
              </button>
            </Link>
            <Link href="/register">
              <button className="px-6 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 font-medium">
                Sign Up
              </button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg text-gray-600 hover:bg-gray-100"
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-100">
            <div className="flex flex-col space-y-4">
              <Link href="/" className="text-gray-600 hover:text-orange-500 font-medium">
                Home
              </Link>
              <Link href="/search" className="text-gray-600 hover:text-orange-500 font-medium">
                Find Services
              </Link>
              <Link href="/providers" className="text-gray-600 hover:text-orange-500 font-medium">
                For Providers
              </Link>
              <Link href="/how-it-works" className="text-gray-600 hover:text-orange-500 font-medium">
                How It Works
              </Link>
              <div className="pt-4 space-y-2">
                <Link href="/login">
                  <button className="w-full px-4 py-2 text-gray-600 hover:text-orange-500 font-medium text-left">
                    Login
                  </button>
                </Link>
                <Link href="/register">
                  <button className="w-full px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 font-medium">
                    Sign Up
                  </button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
