// Sri Lankan Districts
export const SRI_LANKA_DISTRICTS = [
  'Colombo', 'Gampaha', 'Kalutara', 'Kandy', 'Matale', 'Nuwara Eliya',
  'Galle', 'Matara', 'Hambantota', 'Jaffna', 'Kilinochchi', 'Mannar',
  'Vavuniya', 'Mullaitivu', 'Batticaloa', 'Ampara', 'Trincomalee',
  'Kurunegala', 'Puttalam', 'Anuradhapura', 'Polonnaruwa', 'Badulla',
  'Monaragala', 'Ratnapura', 'Kegalle'
] as const;

// Service Categories for WeFix
export const SERVICE_CATEGORIES = [
  { 
    id: 'plumber', 
    name: 'Plumber', 
    icon: '🛠️', 
    rate: '1,500 - 4,000 LKR/hr',
    description: 'Pipe fixing, water tank installation, drainage'
  },
  { 
    id: 'electrician', 
    name: 'Electrician', 
    icon: '⚡', 
    rate: '2,000 - 4,500 LKR/hr',
    description: 'Wiring, switch fixing, electrical repairs'
  },
  { 
    id: 'driver', 
    name: 'Driver', 
    icon: '🚗', 
    rate: '3,000 - 8,000 LKR/day',
    description: 'Personal driver, trip driver, delivery'
  },
  { 
    id: 'maid', 
    name: 'Maid/Cleaner', 
    icon: '🧹', 
    rate: '800 - 1,500 LKR/hr',
    description: 'House cleaning, washing, cooking'
  },
  { 
    id: 'tutor', 
    name: 'Tutor/Teacher', 
    icon: '👨‍🏫', 
    rate: '1,000 - 3,000 LKR/hr',
    description: 'Math, Science, English, IT tuition'
  },
  { 
    id: 'gardener', 
    name: 'Gardener', 
    icon: '🌿', 
    rate: '1,200 - 2,500 LKR/hr',
    description: 'Lawn mowing, tree trimming, gardening'
  },
  { 
    id: 'carpenter', 
    name: 'Carpenter', 
    icon: '🔨', 
    rate: '1,800 - 3,500 LKR/hr',
    description: 'Furniture making, repairs, woodwork'
  },
  { 
    id: 'painter', 
    name: 'Painter', 
    icon: '��', 
    rate: '2,000 - 4,000 LKR/hr',
    description: 'House painting, wall design, exterior'
  },
  { 
    id: 'mechanic', 
    name: 'Mechanic', 
    icon: '🔧', 
    rate: '2,500 - 5,000 LKR/hr',
    description: 'Car repair, bike service, engine fixing'
  },
  { 
    id: 'cook', 
    name: 'Cook/Chef', 
    icon: '👨‍🍳', 
    rate: '1,500 - 3,500 LKR/hr',
    description: 'Home cooking, party catering, meals'
  },
  { 
    id: 'babysitter', 
    name: 'Babysitter', 
    icon: '👶', 
    rate: '1,000 - 2,000 LKR/hr',
    description: 'Child care, babysitting, nanny'
  },
  { 
    id: 'it_support', 
    name: 'IT Support', 
    icon: '💻', 
    rate: '2,000 - 4,000 LKR/hr',
    description: 'Computer repair, network setup, software'
  },
] as const;

// Time slots
export const TIME_SLOTS = [
  { id: 'morning', name: 'Morning (8AM - 12PM)' },
  { id: 'afternoon', name: 'Afternoon (12PM - 5PM)' },
  { id: 'evening', name: 'Evening (5PM - 9PM)' },
  { id: 'flexible', name: 'Flexible (Any Time)' },
];
