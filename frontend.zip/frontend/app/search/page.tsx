export default function SearchPage() {
  const services = [
    { name: "Plumbing", providers: 24, rating: 4.7 },
    { name: "Electrical", providers: 18, rating: 4.8 },
    { name: "Cleaning", providers: 32, rating: 4.5 },
    { name: "Carpentry", providers: 15, rating: 4.6 },
    { name: "AC Repair", providers: 12, rating: 4.9 },
    { name: "Painting", providers: 21, rating: 4.4 },
  ];

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Find Services</h1>
      
      <div className="mb-8">
        <div className="relative">
          <input
            type="text"
            placeholder="Search for services..."
            className="w-full px-4 py-3 pl-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
          <div className="absolute left-4 top-3.5 text-gray-400">
            🔍
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((service, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
            <h3 className="text-xl font-semibold mb-2">{service.name}</h3>
            <div className="flex justify-between text-gray-600 mb-4">
              <span>{service.providers} providers</span>
              <span>{service.rating}★</span>
            </div>
            <button className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700">
              View Providers
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
