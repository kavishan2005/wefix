export default function VerifyOtpPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-md w-full space-y-8 p-8 bg-white rounded-lg shadow-md">
        <h2 className="text-3xl font-bold text-center text-gray-900">Verify OTP</h2>
        <p className="text-center text-gray-600">Enter the 6-digit code sent to your phone</p>
        <form className="mt-8 space-y-6">
          <div className="flex justify-center space-x-2">
            {[1,2,3,4,5,6].map((i) => (
              <input key={i} type="text" maxLength={1} className="w-12 h-12 text-center text-2xl border border-gray-300 rounded-md" />
            ))}
          </div>
          <button type="submit" className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700">
            Verify Code
          </button>
        </form>
      </div>
    </div>
  );
}
