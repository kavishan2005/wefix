import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const providers = [
    { id: 1, name: "Sam's Plumbing", service: "Plumbing", rating: 4.8 },
    { id: 2, name: "Safe Electric", service: "Electrical", rating: 4.9 },
    { id: 3, name: "Clean Pro", service: "Cleaning", rating: 4.7 },
  ];
  return NextResponse.json(providers);
}
