export default function BookServicePage() {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Book a Service</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6">
        <form className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Service Type</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-md">
              <option value="">Select a service</option>
              <option value="plumbing">Plumbing</option>
              <option value="electrical">Electrical</option>
              <option value="cleaning">Cleaning</option>
              <option value="carpentry">Carpentry</option>
              <option value="ac">AC Repair</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Service Description</label>
            <textarea 
              placeholder="Describe what you need..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              rows={4}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Date</label>
              <input type="date" className="w-full px-3 py-2 border border-gray-300 rounded-md" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Preferred Time</label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-md">
                <option value="">Select time</option>
                <option value="morning">Morning (8 AM - 12 PM)</option>
                <option value="afternoon">Afternoon (1 PM - 5 PM)</option>
                <option value="evening">Evening (6 PM - 9 PM)</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Address</label>
            <textarea 
              placeholder="Enter your address..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
              rows={3}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Contact Phone</label>
            <input type="tel" placeholder="+94 77 123 4567" className="w-full px-3 py-2 border border-gray-300 rounded-md" />
          </div>

          <button type="submit" className="w-full bg-green-600 text-white py-3 rounded-md hover:bg-green-700 text-lg font-semibold">
            Book Service Now
          </button>
        </form>
      </div>
    </div>
  );
}
