export default function ProviderEarnings() {
  const earnings = [
    { month: "Jan", amount: 25000 },
    { month: "Feb", amount: 32000 },
    { month: "Mar", amount: 28500 },
    { month: "Apr", amount: 41000 },
  ];

  const total = earnings.reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Earnings</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h2 className="text-xl font-semibold mb-4">Total Earnings</h2>
        <p className="text-4xl font-bold text-green-600">LKR {total.toLocaleString()}</p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold mb-4">Monthly Breakdown</h2>
        <div className="space-y-4">
          {earnings.map((item, index) => (
            <div key={index} className="flex items-center justify-between">
              <span className="font-medium">{item.month} 2024</span>
              <span className="font-semibold">LKR {item.amount.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
