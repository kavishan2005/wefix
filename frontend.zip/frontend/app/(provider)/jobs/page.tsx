export default function ProviderJobs() {
  const jobs = [
    { id: 1, customer: "Alice Smith", service: "Plumbing Repair", date: "2024-01-20", time: "10:00 AM", status: "Scheduled" },
    { id: 2, customer: "Bob Johnson", service: "Electrical Installation", date: "2024-01-21", time: "2:00 PM", status: "Pending" },
    { id: 3, customer: "Carol Williams", service: "AC Service", date: "2024-01-19", time: "11:00 AM", status: "In Progress" },
  ];

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">My Jobs</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {jobs.map((job) => (
          <div key={job.id} className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold mb-2">{job.service}</h3>
            <p className="text-gray-600 mb-2">Customer: {job.customer}</p>
            <p className="text-gray-600 mb-2">Date: {job.date} at {job.time}</p>
            <div className="flex justify-between items-center mt-4">
              <span className={`px-3 py-1 rounded-full text-sm ${
                job.status === 'Scheduled' ? 'bg-blue-100 text-blue-800' :
                job.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                'bg-green-100 text-green-800'
              }`}>
                {job.status}
              </span>
              <button className="text-blue-600 hover:text-blue-800">View Details</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
