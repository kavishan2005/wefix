export default function ProviderProfile() {
  const services = ["Plumbing", "Electrical Work", "AC Repair", "Carpentry"];
  
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Provider Profile</h1>
      <div className="bg-white rounded-lg shadow-md p-6 max-w-2xl">
        <div className="flex items-center space-x-4 mb-6">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
            <span className="text-2xl font-bold text-green-600">SP</span>
          </div>
          <div>
            <h2 className="text-xl font-semibold">Sam's Professional Services</h2>
            <p className="text-gray-600">4.8★ Rating (42 reviews)</p>
            <p className="text-gray-600">Colombo, Sri Lanka</p>
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Business Name</label>
            <input type="text" defaultValue="Sam's Professional Services" className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Contact Person</label>
            <input type="text" defaultValue="Sam Perera" className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Services Offered</label>
            <div className="mt-2 flex flex-wrap gap-2">
              {services.map((service, index) => (
                <span key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                  {service}
                </span>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Description</label>
            <textarea defaultValue="Professional service provider with 10+ years experience in plumbing and electrical work. Licensed and insured." className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md" rows={4} />
          </div>
          <button className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700">
            Update Profile
          </button>
        </div>
      </div>
    </div>
  );
}
